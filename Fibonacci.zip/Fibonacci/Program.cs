﻿namespace Interview_Algo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var nums = Fibonacci();
            await File.WriteAllLinesAsync("WriteLines.txt", nums);
            Thread.Sleep(100000);
        }

        static List<string> Fibonacci()
        {
            List<string> fibonums = new List<string>();
            int n1 = 0, n2 = 1, n3, i, number=50;
            fibonums.Add(n1.ToString());
            fibonums.Add(n2.ToString());
            Console.Write(n1 + " " + n2 + " "); 
            for (i = 2; i < number; ++i) 
            {
                n3 = n1 + n2;
                Console.Write(n3 + "\n");
                fibonums.Add(Convert.ToString(n3));

                n1 = n2;
                n2 = n3;
                Thread.Sleep(1000);
            }
            return fibonums;
        }
    }
}